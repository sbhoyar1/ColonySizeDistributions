%% Introduction

% This script is designed to work on stitched images obtained from a 6
% Well Plate. It outputs a spreadsheet containting data that is analyzed by
% the 'Step2' script.


%% Initialize

close all
clear
warning('OFF', 'images:initSize:adjustingMag'); 
%This turns off the image-size warning (Image is too big to fit on screen;
%displaying at 13%)
%output_filename = 'ColonyData_ki67.xlsx';

% LOOP1: The sequence of wells being analyzed is set here.
all_wells = {'A1', 'A2', 'A3', 'B1', 'B2', 'B3'};

% LOOP2: The loop is currently set to analyzing one 1 timepoint at a time.
timepoint1 = 1; timepoint2 = 1;

for well_counter = 1:length(all_wells)  % Loop 1
    well = all_wells{well_counter}
    
N = [];
    
    % Get lists of RFP, GFP, DAPI and KI67 images
[list_r, list_g, list_d, list_c] = choose_images_rgdc(well);

for j = timepoint1:timepoint2           % Loop 2
    disp(j)
    
    % Read Images
    GFP = imread(list_g{j});
    RFP = imread(list_r{j});
    DAPI = imread(list_d{j});
    KI67 = imread(list_c{j});
    
    GFP_name = list_g{j};
    k = strfind(list_g{j}, '_D_');
    Day(j) = str2num(strcat(GFP_name(k+3), GFP_name(k+4))); 



%% Preprocessing
KI67 = imtophat(KI67, strel('disk', 50));

    % RFP and GFP masks
GFP_mask = green_mask(GFP, 0.05);
RFP_mask = red_mask(RFP, 0.03);

clear GFP RFP
close all

%% SEGMENT COLONIES IN DAPI CHANNEL
    
    % Processing
DAPI_preprocess = colony_preprocess(DAPI, 200);


DAPI_watershed = watershed_disttr(DAPI_preprocess);

DAPI_cc = bwconncomp(DAPI_watershed);
DAPI_data = regionprops(DAPI_cc, 'Area', 'PixelIdxList', 'BoundingBox');

%% LOOP OVER EACH COLONY AND OBTAIN METRICS
M = zeros(DAPI_cc.NumObjects, 6); % 
for i = 1:DAPI_cc.NumObjects 
    disp(i)
    [Area_i, CellCount_i, SumInt_i, SumIntBin_i, KI67Frac_i] = colony_metrics_ki67(DAPI_data, DAPI, KI67, i, 1, 0);
    redfrac_i = colony_classify(DAPI_data, RFP_mask, GFP_mask, i);
    M(i, :) = [Area_i, CellCount_i, SumInt_i, SumIntBin_i, KI67Frac_i, redfrac_i];
end

M(:, 7) = Day(j)



N = [N;M];
end  %Timepoint loop ends (LOOP 2)


%% OUTPUT SPREADSHEET
output_filename = strcat(well, '_data.xlsx');
xlswrite(output_filename, N);

end % Well loop ends      (LOOP 1)

